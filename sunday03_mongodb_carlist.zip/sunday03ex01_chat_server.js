// sunday03ex01_chat_server.js
const http = require('http');
const express = require('express');
const path = require('path');
const cors = require('cors');
const static = require('serve-static');
const app = express();
const router = express.Router();

app.set('port', 3000);

app.use(cors());
app.use('/public', static(path.join(__dirname, 'public')));

let msgArr = [];

router.route('/recieve').get(function(req, res) {
    var size = Number(req.query.size);
    
    if(size < msgArr.length) {
        var response = {
            total : msgArr.length,
            msgArr: msgArr.slice(size)
        }
        console.log(response);
        res.end(JSON.stringify(response));
    } else {
        res.end();
    }
});

router.route('/send').get(function (req, res) {
    var message = {
        sender : req.query.sender,
        message : req.query.message
    };
    msgArr.push(message);
    //console.log(message);
    res.end();
});

app.use('/', router);
const server = http.createServer(app);
server.listen(app.get('port'), function () {
    console.log('http://localhost:%d로 서비중~', app.get('port'));
});
