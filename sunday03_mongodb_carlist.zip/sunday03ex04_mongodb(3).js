// sunday03ex04_mongodb.js
const http = require('http');
const express = require('express');
const app = express();
const router = express.Router();
const path = require('path');
const MongoClient = require('mongodb').MongoClient;
const bodyParser = require('body-parser');
const static = require('serve-static');

app.set('port', 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use('/public', static(path.join(__dirname, 'public')) );

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

let db;
let dbUrl = 'mongodb://localhost';
function connectDb() {
    MongoClient.connect(dbUrl, function(err, client) {
        if(err) throw err;
        
        db = client.db('vehicle');
        console.log('db 접속 완료 : ', dbUrl);
    });
}

/////////
function getCarList(db, callback) {
    let car = db.collection('car');
    car.find().toArray(function(err, carList) {
        if(err) {
            callback(err, null);
            return;
        }

        if(carList != null) {
            callback(null, carList);
        } else {
            callback(null, null);
        }
    });
}

/////

router.route('/car').get(function(req, res) {
    console.log('GET - /car 요청 됨');
    if(db) {
        getCarList(db, function(err, carList) {
            if(err) throw err;
            if(carList != null) {
                req.app.render('car_list', {carList: carList}, function(err2, html) {
                    if(err2) throw err;
                    res.end(html);
                });
            }
        });
    } else {
        console.log('db 접속 안됨!');
    }
});

router.route('/car').post(function(req, res) {
    console.log('POST - /car 요청 됨');
    
    let carData = {
        name: req.body.name,
        price: req.body.price,
        company: req.body.company,
        year: req.body.year
    };
    
    if(db) {
        db.collection('car').save(carData).then(function(err, result) {
            console.log('차 정보 입력 완료!', result);
            
            res.redirect('/car');
        });
    } else {
        console.log('db 접속 안됨!');
    }
});

app.use('/', router);
const server = http.createServer(app);
server.listen(app.get('port'), function() {
    console.log('http://localhost:%d', app.get('port'));
    connectDb();
});