// sunday03ex02_monogjs.js
// npm install mongojs --save

var mongojs = require('mongojs');
var db = mongojs('vehicle', ['car']);

db.car.find(function(err, docList) {
    console.log(docList);
});