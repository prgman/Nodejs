// sunday03ex04_mongodb.js
const http = require('http');
const express = require('express');
const app = express();
const router = express.Router();
const path = require('path');

app.set('port', 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

let carList = [
    {name:'Sonata', price:3200, company: 'HYUNDAI', year: 2018},
    {name:'BMW', price:4200, company: 'BMW', year: 2016}
];

router.route('/car').get(function(req, res) {
    console.log('/car 요청 됨');
    
    req.app.render('car_list', {carList: carList}, function(err, html) {
        if(err) throw err;
        res.end(html);
    });
});

app.use('/', router);
const server = http.createServer(app);
server.listen(app.get('port'), function() {
    console.log('http://localhost:%d', app.get('port'));
});