// sunday03ex03_mongodb_connection.js
const MongoClient = require('mongodb').MongoClient;
MongoClient.connect('mongodb://localhost', function (err, client) {
    if (err) throw err;

    var db = client.db('vehicle');
    
    var car = db.collection('car');
    /*car.findOne({}, function(findErr, result) {
        if(findErr) throw findErr;
        
        console.log(result.name);
        client.close();
    });*/
    
    car.find({}).toArray(function(err, docArr) {
        console.log(docArr);
    });
});
